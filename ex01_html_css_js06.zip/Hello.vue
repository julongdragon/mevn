<template lang="pug">
    
    div {{msg}}
        p  {{msg}}
        h1.hello {{msg}}
        h2.g Essential Links
        ul
        li: a(href="#" target="_blank") Core Docs
        li: a(href="#" target="_blank") Forum
        li: a(href="#" target="_blank") Gitter Chat
        li: a(href="#" target="_blank") Twitter
        h2 Ecosystem2
        ul
        li: a(ref="#" target="_blank") vue-router
        li: a(ref="#" target="_blank") vuex
        li: a(ref="#" target="_blank") vue-loader
        li: a(ref="#" target="_blank") awesome-vue

</template>

<script>
/* eslint-disable */
export default {
    data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>
