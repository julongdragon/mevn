<template>
  <div class="hello">
    {{ msg }}

    <div v-if="showLogo">
      <i class="fa fa-spinner fa-spin fa-3x"></i>
    </div>

   <p>
     <i class="fa fa-user-circle"></i>
     Type Something : <input type="text" v-model="msg">
   </p>
   <p>
     <button v-on:click="sayMyName">Click!!</button>
   </p>
   <ul v-for="product in items">
     <li> {{ product.name  }} : <b>{{product.price}}</b> </li>
   </ul>
  </div>
</template>
<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      showLogo : false,
      items : [
        {name: 'iPhone X', price: 45000},
        {name: 'iMac', price: 200000},
        {name: 'Watch', price: 14000},
        {name: 'Beats Wireless Studio 3', price: 12500}
      ]
    }
  },
  methods: {
    sayMyName : function(){
      this.showLogo = !this.showLogo;
      console.log("click");
      //swal("Here's the title!", "...and here's the text!");
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
